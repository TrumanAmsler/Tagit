(() => {
  const TAGIT_ID = "tagit-moxfield-root";
  const DECK_ID_RE = /moxfield\.com\/decks\/([^/?#]+)/i;
  const SCRYFALL_DELAY_MS = 80;

  const DEFAULT_OPTIONS = {
    ignoreTagged: true,
    includeLands: false,
    splitRemoval: true,
    tagMixSource: "current",
    tagMixExpanded: false,
    maxTagsPerCard: 4
  };

  const DETAILED_REMOVAL_TAGS = new Set([
    "Creature Removal",
    "Artifact Removal",
    "Enchantment Removal",
    "Permanent Removal",
    "Bounce"
  ]);

  const DRAW_EFFECT_TAGS = new Set(["Cantrip", "Card Advantage", "Draw"]);
  const ZONE_ONLY_TAGS = new Set(["Commander"]);
  const IGNORED_VISIBLE_HEADINGS = new Set(["Commander", "Main Deck", "Mainboard", "Sideboard", "Maybeboard", "Considering", "Other"]);

  const TAG_RULES = [
    { tag: "Mana Rock", tests: [/\{t\}.*add (\{[wubrgc/]+\}|.* mana)/i, /tap.*add .* mana/i], names: ["Sol Ring", "Arcane Signet", "Fellwar Stone", "Mind Stone", "Mana Crypt", "Mana Vault", "Chrome Mox", "Mox Diamond", "Lotus Petal", "Jeweled Lotus", "Talisman of Dominance", "Thought Vessel"], excludeNames: ["The Aetherspark"], typeIncludes: ["Artifact"], typeExcludes: ["Creature", "Land"] },
    { tag: "Mana Dork", tests: [/\{t\}.*add (\{[wubrgc/]+\}|.* mana)/i, /add(s)? .* mana/i], names: ["Llanowar Elves", "Elvish Mystic", "Birds of Paradise", "Noble Hierarch", "Bloom Tender", "Delighted Halfling"], typeIncludes: ["Creature"] },
    { tag: "Land Ramp", tests: [/search your library for .* land.*put .* onto the battlefield/i, /put .* land card .* onto the battlefield/i, /you may play an additional land/i, /play an additional land/i], names: ["Rampant Growth", "Cultivate", "Kodama's Reach", "Nature's Lore", "Three Visits", "Farseek", "Sakura-Tribe Elder"], typeExcludes: ["Land"] },
    { tag: "Ritual", tests: [/\badd(s)? (one|two|three|four|five|six|seven|eight|nine|ten|x|\{[wubrgc/]+\}).* mana/i], names: ["Dark Ritual", "Cabal Ritual", "Jeska's Will", "Seething Song", "High Tide", "Mana Geyser", "Rite of Flame", "The Aetherspark"], exclude: [/treasure token/i], typeIncludesAny: ["Instant", "Sorcery", "Artifact"] },
    { tag: "Cost Reduction", tests: [/cost(s)? .* less to cast/i, /spells you cast cost .* less/i, /abilities .* cost .* less/i], names: ["Goblin Electromancer", "Foundry Inspector", "Etherium Sculptor", "Jhoira's Familiar", "Training Grounds"] },
    { tag: "Fixing", tests: [/mana of any color/i, /mana in any combination of colors/i, /one mana of any type/i, /add one mana of any color/i], names: ["Chromatic Lantern", "Arcane Signet", "Fellwar Stone"], exclude: [/treasure token/i], typeExcludes: ["Land", "Instant", "Sorcery"] },
    { tag: "Ramp", tests: [/\badd(s)? .* mana/i, /\{t\}.*add \{[wubrgc/]+\}/i, /create .* treasure token/i, /put .* land card .* onto the battlefield/i, /play an additional land/i], names: ["Sol Ring", "Arcane Signet", "Rampant Growth", "Cultivate", "Kodama's Reach", "Dark Ritual"], exclude: [/its controller creates?.*treasure/i, /target opponent creates?.*treasure/i], typeExcludes: ["Land"] },
    { tag: "Emerge", tests: [/\bemerge\b/i] },
    { tag: "Gambit", tests: [/flip a coin/i, /coin flip/i, /roll (a|one or more) d\d+/i, /roll (a|one or more) dice/i, /whenever you roll/i], names: ["Krark's Thumb", "Wyll, Blade of Frontiers", "Barbarian Class", "Delina, Wild Mage"] },
    { tag: "Cantrip", tests: [/draw a card/i], typeIncludesAny: ["Instant", "Sorcery"] },
    { tag: "Loot", tests: [/draw .* discard/i, /discard .* draw/i, /then discard/i, /rummage/i] },
    { tag: "Wheel", tests: [/discard.*hand.*draw/i, /each player.*discards.*hand/i, /each player.*draws seven/i], names: ["Windfall", "Wheel of Fortune", "Wheel of Misfortune", "Reforge the Soul", "Time Spiral"] },
    { tag: "Card Advantage", tests: [/draw (two|three|four|x|that many) cards?/i, /whenever .* draw/i, /you may cast .* without paying/i, /you may play .* from exile/i, /return .* from your graveyard to your hand/i, /investigate/i] },
    { tag: "Draw", tests: [/draw (a|two|three|four|x|that many) cards?/i, /draw cards equal/i, /whenever .* draw/i, /investigate/i] },
    { tag: "Tutor", tests: [/search your library for (a|an|any|up to)/i, /search your library .* reveal/i, /transmute/i], exclude: [/basic land/i, /land card/i], typeExcludes: ["Land"] },
    { tag: "Creature Removal", group: "removalDetail", tests: [/destroy target creature/i, /exile target creature/i, /target creature gets -/i, /deals? .* damage to target creature/i] },
    { tag: "Artifact Removal", group: "removalDetail", tests: [/destroy target artifact/i, /exile target artifact/i] },
    { tag: "Enchantment Removal", group: "removalDetail", tests: [/destroy target enchantment/i, /exile target enchantment/i] },
    { tag: "Permanent Removal", group: "removalDetail", tests: [/destroy target permanent/i, /exile target permanent/i, /exile (up to )?(one|two|three|\d+) target permanents?/i, /destroy target nonland permanent/i, /exile target nonland permanent/i] },
    { tag: "Land Hate", allowWhenLandsDisabled: true, tests: [/destroy target land/i, /exile target land/i, /destroy all lands/i, /nonbasic lands?/i, /lands? don't untap/i, /whenever .* land .* tapped for mana/i], names: ["Strip Mine", "Wasteland", "Blood Moon", "Magus of the Moon", "Back to Basics", "Armageddon"] },
    { tag: "Bounce", group: "removalDetail", tests: [/return target .* to (its owner's|their owner's) hand/i, /return .* to (its owner's|their owner's) hand/i] },
    { tag: "Removal", tests: [/destroy target/i, /exile target/i, /exile (up to )?(one|two|three|\d+) target/i, /return target .* to (its owner's|their owner's) hand/i, /deals? .* damage to target/i, /target creature gets -/i] },
    { tag: "Board Wipe", tests: [/destroy all/i, /exile all/i, /return all .* to (their|its) owners'? hands/i, /all creatures get -/i, /deals? .* damage to each creature/i, /each creature gets -/i, /sacrifice all/i, /exile all permanents/i, /each player sacrifices all/i], names: ["All Is Dust", "Ugin's Binding"] },
    { tag: "Counterspell", tests: [/counter target .* spell/i, /counter target spell/i, /counter up to one target spell/i], names: ["Counterspell", "Mana Drain", "Force of Will", "Force of Negation", "Swan Song", "Pact of Negation", "Flusterstorm"] },
    { tag: "Ability Counter", tests: [/counter target activated or triggered ability/i, /counter target ability/i], names: ["Stifle", "Disallow", "Tale's End", "Trickbind", "Defabricate"] },
    { tag: "Protection", tests: [/gain(s)? indestructible/i, /hexproof/i, /protection from/i, /phase out/i, /can't be the target/i, /prevent all damage/i, /ward/i] },
    { tag: "+X/+-X", tests: [/gets? \+[x\d*]+\/\+[x\d*]+/i, /gets? -[x\d*]\/-[x\d*]/i, /gets? \+[x\d*]\/-[x\d*]/i, /gets? -[x\d*]\/\+[x\d*]/i, /\+[x\d*]\/\+[x\d*] until end of turn/i, /\+\d+\/\+\d+ counters?/i, /additional \+\d+\/\+\d+ counters?/i] },
    { tag: "Evasion", tests: [/\bflying\b/i, /\btrample\b/i, /\bmenace\b/i, /\bskulk\b/i, /\bshadow\b/i, /\bfear\b/i, /\bintimidate\b/i, /can't be blocked/i, /unblockable/i, /islandwalk|swampwalk|forestwalk|mountainwalk|plainswalk|landwalk/i] },
    { tag: "Flash", tests: [/\bflash\b/i, /as though .* had flash/i, /any time you could cast an instant/i] },
    { tag: "Haste", tests: [/\bhaste\b/i, /gains haste/i, /have haste/i] },
    { tag: "Fog", tests: [/prevent all combat damage/i, /prevent all damage that would be dealt this turn/i, /creatures? .* would deal no combat damage/i], names: ["Fog", "Constant Mists", "Spore Frog", "Arachnogenesis", "Teferi's Protection"] },
    { tag: "Recursion", tests: [/return target .* from your graveyard/i, /return .* from your graveyard to/i, /cast .* from your graveyard/i, /from your graveyard/i] },
    { tag: "Reanimation", tests: [/return target .* from your graveyard to the battlefield/i, /put target .* from a graveyard onto the battlefield/i, /reanimate/i], names: ["Reanimate", "Animate Dead", "Necromancy", "Victimize", "Living Death"] },
    { tag: "Graveyard Hate", tests: [/exile .* graveyard/i, /exile all cards from target player's graveyard/i, /cards in graveyards can't/i, /would be put into .* graveyard.*exile/i, /players can't cast spells from graveyards/i], names: ["Tormod's Crypt", "Soul-Guide Lantern", "Relic of Progenitus", "Rest in Peace", "Bojuka Bog", "Grafdigger's Cage"], excludeNames: ["Ugin's Binding"] },
    { tag: "Self-Mill", tests: [/mill .* cards?/i, /surveil/i, /put the top .* cards? of your library into your graveyard/i] },
    { tag: "Mill", tests: [/target player mills/i, /each opponent mills/i, /each player mills/i, /mill .* cards?/i] },
    { tag: "Poison", tests: [/poison counter/i, /\binfect\b/i, /\btoxic\b/i, /\bproliferate\b/i, /gets? .* poison counters?/i], names: ["Triumph of the Hordes", "Blightsteel Colossus", "Venerated Rotpriest"] },
    { tag: "Proliferate", tests: [/\bproliferate\b/i], names: ["Evolution Sage", "Contagion Engine", "Inexorable Tide", "Tekuthal, Inquiry Dominus"] },
    { tag: "Tokens", tests: [/create .* token/i, /populate/i] },
    { tag: "Copy", tests: [/copy target/i, /copy .* spell/i, /create a token that's a copy/i, /becomes a copy/i, /you may have .* enter .* as a copy/i], names: ["Helm of the Host", "Sculpting Steel", "Phyrexian Metamorph", "Twincast", "Lithoform Engine", "Strionic Resonator"], excludeNames: ["Chain of Vapor"] },
    { tag: "Sac Outlet", tests: [/sacrifice (a|another|one or more) (creature|artifact|permanent|token)/i, /sacrifice .*:/i, /, sacrifice .*:/i], names: ["Ashnod's Altar", "Phyrexian Altar", "Viscera Seer", "Carrion Feeder", "Goblin Bombardment", "Altar of Dementia", "Woe Strider"], exclude: [/treasure token/i, /sacrifice this artifact: add/i] },
    { tag: "Stax", tests: [/can't untap/i, /players can't/i, /spells cost .* more/i, /unless (that player|they) pay/i, /skip .* step/i, /doesn't untap/i, /only any time they could cast a sorcery/i], names: ["Propaganda", "Ghostly Prison", "Rhystic Study", "Smothering Tithe", "Winter Orb", "Static Orb"] },
    { tag: "Control", tests: [/\bcounter target/i, /\btap target/i, /doesn't untap/i, /gain control of target/i, /detain/i, /loses? all abilities/i, /lose all abilities/i, /becomes? a .* with no abilities/i, /becomes? a colorless land/i, /is a colorless land/i, /look at target (player's|opponent's) hand/i, /look at each opponent's hand/i, /target (player|opponent) reveals? their hand/i, /each opponent reveals? their hand/i, /exchange control of/i, /exchange control of target/i, /exchange .* you control .* target .* an opponent controls/i], names: ["Oko, Thief of Crowns", "Imprisoned in the Moon", "Song of the Dryads", "Darksteel Mutation", "Kenrith's Transformation", "Shifting Grift"] },
    { tag: "Theft", tests: [/gain control of target/i, /gain control of .* until end of turn/i, /untap .* gain haste until end of turn/i, /you control enchanted/i, /you may cast .* from among them/i], names: ["Claim the Firstborn", "Traitorous Greed", "Act of Treason", "Control Magic", "Agent of Treachery"] },
    { tag: "Ping", tests: [/deals? 1 damage to (any target|each opponent|target player|target creature)/i, /deals? [x\d]+ damage to (any target|each opponent|target player|target creature)/i, /whenever .* deals? 1 damage/i], names: ["Thermo-Alchemist", "Prodigal Pyromancer", "Goblin Fireslinger"] },
    { tag: "Group Slug", tests: [/each opponent loses/i, /each opponent takes/i, /deals? .* damage to each opponent/i, /whenever .* each opponent/i, /at the beginning of each player's upkeep.*damage/i], names: ["Impact Tremors", "Purphoros, God of the Forge", "Sulfuric Vortex", "Zo-Zu the Punisher", "Kambal, Consul of Allocation"] },
    { tag: "Life Gain", tests: [/you gain \d+ life/i, /you gain [xX] life/i, /you gain life equal/i, /lifelink/i, /whenever you gain life/i], names: ["Soul Warden", "Soul's Attendant", "Aetherflux Reservoir", "Authority of the Consuls"] },
    { tag: "Combo Piece", tests: [/untap target .* permanent/i, /whenever .* untap/i, /copy .* activated ability/i, /activate abilities .* without paying/i, /you may cast .* without paying (its|their) mana cost/i], names: ["Isochron Scepter", "Dramatic Reversal", "Basalt Monolith", "Rings of Brighthearth", "Freed from the Real", "Pemmin's Aura", "Deadeye Navigator", "Intruder Alarm"] },
    { tag: "Payoff", tests: [/whenever .* enters .* battlefield.*draw/i, /whenever .* dies.*draw/i, /whenever .* dies.*each opponent/i, /whenever .* cast .* copy/i, /whenever .* cast .* create/i, /whenever .* draw/i, /whenever .* sacrifice .* each opponent/i, /whenever you cast .* (create|draw|put|you may)/i, /whenever .* cast .* with mana value .* (draw|create)/i, /if you do, (draw|create|put)/i], names: ["Impact Tremors", "Purphoros, God of the Forge", "Blood Artist", "Zulaport Cutthroat", "Altar of the Brood", "Psychosis Crawler", "Aetherflux Reservoir", "Chasm Skulker", "Kozilek's Unsealing"] },
    { tag: "Wincon", tests: [/you win the game/i, /target player loses the game/i, /each opponent loses/i, /you get an emblem/i, /extra turn/i, /can't lose the game/i, /exiles? the top (twenty|20) cards/i], names: ["Thassa's Oracle", "Laboratory Maniac", "Jace, Wielder of Mysteries", "Approach of the Second Sun", "Expropriate", "Ulamog, the Defiler"] }
  ];

  const state = {
    options: { ...DEFAULT_OPTIONS },
    deck: null,
    suggestions: [],
    currentTagMixItems: [],
    output: ""
  };

  globalThis.__tagitTest = {
    classifyForTest: classify,
    collectDeckEntriesForTest: collectDeckEntries,
    getTagDistributionForTest: getTagDistribution,
    getDistributionSourceForTest: getDistributionSource,
    collectVisibleTagMixItemsForTest: collectVisibleTagMixItems,
    collectVisibleTagCountsForTest: collectVisibleTagCounts,
    formatBulkLineForTest: formatBulkLine
  };

  if (document.getElementById(TAGIT_ID)) return;

  const root = document.createElement("div");
  root.id = TAGIT_ID;
  root.className = "tagit-root";
  root.innerHTML = `
    <button class="tagit-tab" type="button" title="Open Tagit" aria-label="Open Tagit">
      <span class="tagit-star" aria-hidden="true"></span>
      <span class="tagit-star-core" aria-hidden="true"></span>
    </button>
    <section class="tagit-panel tagit-hidden" aria-label="Tagit Moxfield Auto Tagger">
      <div class="tagit-header">
        <div>
          <h2 class="tagit-title">Tagit</h2>
          <p class="tagit-subtitle">Suggest Moxfield purpose tags, then paste them into Bulk Edit.</p>
        </div>
        <button class="tagit-close" type="button" title="Close">x</button>
      </div>
      <div class="tagit-body">
        <div class="tagit-actions">
          <button class="tagit-button" data-action="analyze" type="button">Analyze deck</button>
          <button class="tagit-button secondary" data-action="copy" type="button" disabled>Copy tagged list</button>
          <button class="tagit-button secondary" data-action="fill" type="button" disabled>Fill Bulk Edit</button>
        </div>
        <div class="tagit-options">
          <label class="tagit-check"><input type="checkbox" data-option="ignoreTagged" checked> Ignore cards that already have tags</label>
          <label class="tagit-check"><input type="checkbox" data-option="includeLands"> Include land tags</label>
          <label class="tagit-check"><input type="checkbox" data-option="splitRemoval" checked> Split removal into specific tags</label>
        </div>
        <p class="tagit-status">Open a Moxfield deck page and press Analyze deck.</p>
        <div class="tagit-distribution tagit-hidden" aria-label="Tag distribution"></div>
        <div class="tagit-results"></div>
        <textarea class="tagit-output tagit-hidden" spellcheck="false" aria-label="Tagged Moxfield bulk edit output"></textarea>
      </div>
    </section>
  `;
  document.documentElement.appendChild(root);

  const tab = root.querySelector(".tagit-tab");
  const panel = root.querySelector(".tagit-panel");
  const close = root.querySelector(".tagit-close");
  const status = root.querySelector(".tagit-status");
  const distribution = root.querySelector(".tagit-distribution");
  const results = root.querySelector(".tagit-results");
  const output = root.querySelector(".tagit-output");
  const analyzeButton = root.querySelector('[data-action="analyze"]');
  const copyButton = root.querySelector('[data-action="copy"]');
  const fillButton = root.querySelector('[data-action="fill"]');
  let isTransitioning = false;

  tab.addEventListener("click", () => {
    if (isTransitioning) return;
    isTransitioning = true;
    root.classList.add("tagit-opening");
    window.setTimeout(() => {
      tab.classList.add("tagit-hidden");
      panel.classList.remove("tagit-hidden");
      root.classList.remove("tagit-opening");
      panel.classList.add("tagit-panel-open");
      window.setTimeout(() => {
        panel.classList.remove("tagit-panel-open");
        isTransitioning = false;
      }, 260);
    }, 180);
  });

  close.addEventListener("click", () => {
    if (isTransitioning) return;
    isTransitioning = true;
    panel.classList.add("tagit-panel-close");
    window.setTimeout(() => {
      panel.classList.add("tagit-hidden");
      panel.classList.remove("tagit-panel-close");
      tab.classList.remove("tagit-hidden");
      root.classList.add("tagit-closing");
      window.setTimeout(() => {
        root.classList.remove("tagit-closing");
        isTransitioning = false;
      }, 260);
    }, 180);
  });

  root.querySelectorAll("[data-option]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      state.options[checkbox.dataset.option] = checkbox.checked;
      if (state.deck) {
        state.suggestions = state.suggestions.map((item) => ({ ...item, tags: classify(item) }));
        renderSuggestions();
      }
    });
  });

  distribution.addEventListener("click", (event) => {
    const expandButton = event.target.closest("[data-mix-expand]");
    if (expandButton) {
      state.options.tagMixExpanded = !state.options.tagMixExpanded;
      renderSuggestions();
      return;
    }

    const button = event.target.closest("[data-mix-source]");
    if (!button) return;
    state.options.tagMixSource = button.dataset.mixSource;
    renderSuggestions();
  });

  analyzeButton.addEventListener("click", async () => {
    setBusy(true, "Fetching the Moxfield deck...");
    try {
      const deckId = getDeckId();
      if (!deckId) throw new Error("This does not look like a Moxfield deck URL.");
      state.deck = await fetchDeck(deckId);
      setStatus("Reading card text and assigning roles...");
      state.suggestions = await buildSuggestions(state.deck);
      renderSuggestions();
    } catch (error) {
      setStatus(error.message || "Something went wrong while analyzing this deck.");
      console.error("[Tagit]", error);
    } finally {
      setBusy(false);
    }
  });

  copyButton.addEventListener("click", async () => {
    try {
      await navigator.clipboard.writeText(state.output);
      setStatus("Tagged list copied. In Moxfield, open Bulk Edit, replace the list, and save.");
    } catch {
      output.classList.remove("tagit-hidden");
      output.select();
      setStatus("Clipboard access was blocked. The tagged list is selected below.");
    }
  });

  fillButton.addEventListener("click", () => {
    const filled = fillBulkEditor(state.output);
    if (filled) {
      setStatus("Filled the visible Bulk Edit editor. Review the list, then press Moxfield's save button.");
      return;
    }

    const opened = clickBulkEdit();
    if (opened) {
      setStatus("Opened Bulk Edit. Press Fill Bulk Edit again after the editor finishes loading.");
      return;
    }

    setStatus("I could not find Bulk Edit on this page. Open Moxfield Bulk Edit, then press Fill Bulk Edit again.");
  });

  function getDeckId() {
    const match = window.location.href.match(DECK_ID_RE);
    return match?.[1] || null;
  }

  async function fetchDeck(deckId) {
    const url = `https://api2.moxfield.com/v2/decks/all/${encodeURIComponent(deckId)}`;
    try {
      return await sendMessage({ type: "fetchJson", url });
    } catch (backgroundError) {
      try {
        const response = await fetch(url, {
          credentials: "include",
          headers: { Accept: "application/json" }
        });
        if (!response.ok) throw new Error(`Request returned ${response.status}`);
        return response.json();
      } catch {
        const visibleDeck = collectVisibleDeck();
        if (Object.keys(visibleDeck.mainboard).length || Object.keys(visibleDeck.commanders).length) {
          setStatus("Moxfield blocked the deck API here, so I am using the visible card list on the page.");
          return visibleDeck;
        }
        throw backgroundError;
      }
    }
  }

  async function buildSuggestions(deck) {
    const entries = collectDeckEntries(deck);
    const suggestions = [];
    for (const entry of entries) {
      const enriched = await enrichEntry(entry);
      suggestions.push({
        ...enriched,
        tags: classify(enriched)
      });
      await wait(SCRYFALL_DELAY_MS);
    }
    return suggestions;
  }

  function collectDeckEntries(deck) {
    const protectedNames = getProtectedZoneNames(deck);
    state.currentTagMixItems = collectVisibleTagMixItems(Object.values(deck.mainboard || {}).map(getEntryName));
    const entries = [];
    Object.values(deck.mainboard || {}).forEach((entry) => {
      const card = entry.card || entry;
      const name = card.name || entry.name;
      if (!name || protectedNames.has(normalizeCardName(name))) return;
      entries.push({
        zone: "Mainboard",
        quantity: entry.quantity || entry.qty || entry.count || 1,
        name,
        card,
        existingTags: normalizeExistingTags(entry)
      });
    });
    return entries;
  }

  function mergeTags(...tagLists) {
    const merged = new Set();
    tagLists.flat().forEach((tag) => {
      if (tag) merged.add(tag);
    });
    return [...merged];
  }

  function collectVisibleTagMap(deckNames = []) {
    const pageText = getVisibleDeckText();
    if (!pageText) return new Map();

    const tagMap = new Map();
    const lines = pageText.split(/\n+/).map((line) => line.trim()).filter(Boolean);
    let currentTag = "";

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const heading = parseVisibleTagHeadingSafe(line);
      if (heading) {
        currentTag = isIgnoredVisibleHeading(heading) ? "" : heading;
        continue;
      }
      if (!currentTag) continue;

      let match = line.match(/^(\d+)\s+(.+)$/);
      if (!match && /^\d+$/.test(line) && lines[index + 1]) {
        match = [null, line, lines[index + 1]];
        index += 1;
      }
      if (!match) continue;

      const quantity = Number(match[1]);
      const name = cleanupBulkEditCardName(match[2]);
      if (!quantity || !name || name.length > 80) continue;

      const key = normalizeCardName(name);
      const tags = tagMap.get(key) || [];
      if (!tags.includes(currentTag)) tags.push(currentTag);
      tagMap.set(key, tags);
    }

    return tagMap;
  }

  function collectVisibleTagMixItems(deckNames = []) {
    const counts = collectVisibleTagCounts(deckNames);
    return [...counts.entries()].map(([tag, count]) => ({
      tags: Array.from({ length: count }, () => tag),
      existingTags: Array.from({ length: count }, () => tag)
    }));
  }

  function collectVisibleTagCounts(deckNames = []) {
    const pageText = getVisibleDeckText();
    if (!pageText || !deckNames.length) return new Map();

    const knownNames = new Set(deckNames.map(normalizeBulkEditCardName).filter(Boolean));
    const inlineCounts = collectInlineTagCounts(pageText, knownNames);
    if (inlineCounts.size) return inlineCounts;

    if (typeof document.querySelectorAll === "function") {
      const domListCounts = collectDomListTagCounts(knownNames);
      if (domListCounts.size) return domListCounts;

      const domRowCounts = collectDomCardScopedTagCounts(knownNames);
      if (domRowCounts.size) return domRowCounts;
      return new Map();
    }

    return collectTextRowTagCounts(pageText, knownNames);
  }

  function collectDomListTagCounts(knownNames) {
    const counts = new Map();
    const knownNameList = [...knownNames].sort((a, b) => b.length - a.length);
    const lists = [...(document.querySelectorAll?.("ul, ol, [role='list']") || [])];
    const countedGroups = new Set();

    lists.forEach((list) => {
      if (list.closest?.(`#${TAGIT_ID}`)) return;

      const rawText = list.innerText || list.textContent || "";
      const lines = rawText.split(/\n+/).map((line) => cleanupVisibleName(line)).filter(Boolean);
      const heading = parseSplitVisibleTagHeading(lines);
      if (!heading || isIgnoredVisibleHeading(heading.heading)) return;

      const cardText = lines.slice(heading.linesConsumed).join(" ");
      if (!findKnownCardNameInText(cardText, knownNameList)) return;

      const position = getElementPosition(list);
      const groupKey = `${heading.heading}:${heading.count}:${Math.round(position.left)}:${Math.round(position.top)}`;
      if (countedGroups.has(groupKey)) return;
      countedGroups.add(groupKey);
      counts.set(heading.heading, Math.max(counts.get(heading.heading) || 0, heading.count));
    });

    return counts;
  }

  function collectTextRowTagCounts(text, knownNames) {
    const counts = new Map();
    const knownNameList = [...knownNames].sort((a, b) => b.length - a.length);
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);
    let currentHeading = null;
    const countedHeadings = new Set();

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      const heading = parseVisibleTagHeadingInfo(line);
      if (heading) {
        currentHeading = isIgnoredVisibleHeading(heading.heading) || isUtilityHeadingAtLine(lines, index) ? null : heading;
        continue;
      }
      if (!currentHeading) continue;

      let match = line.match(/^(\d+)\s+(.+)$/);
      if (!match && /^\d+$/.test(line) && lines[index + 1]) {
        match = [null, line, lines[index + 1]];
        index += 1;
      }
      if (!match) continue;

      const quantity = Number(match[1]);
      const matchedName = findKnownCardNameInText(match[2], knownNameList);
      if (!quantity || !matchedName) continue;

      const headingKey = `${currentHeading.heading}:${currentHeading.count}`;
      if (currentHeading.count && !countedHeadings.has(headingKey)) {
        counts.set(currentHeading.heading, Math.max(counts.get(currentHeading.heading) || 0, currentHeading.count));
        countedHeadings.add(headingKey);
        continue;
      }
      if (!currentHeading.count) counts.set(currentHeading.heading, (counts.get(currentHeading.heading) || 0) + quantity);
    }

    return counts;
  }

  function collectDomCardScopedTagCounts(knownNames) {
    const counts = new Map();
    const knownNameList = [...knownNames].sort((a, b) => b.length - a.length);
    const elements = [...(document.querySelectorAll?.("h1, h2, h3, h4, h5, h6, strong, b, div, span, a") || [])];
    const headings = [];
    const cardRows = [];

    elements.forEach((element) => {
      if (element.closest?.(`#${TAGIT_ID}`)) return;
      const rawText = element.innerText || element.textContent || "";
      const text = cleanupVisibleName(rawText);
      if (!text || text.length > 140 || /[\n\r]/.test(rawText)) return;

      const heading = parseVisibleTagHeadingInfo(text);
      if (heading) {
        if (!isIgnoredVisibleHeading(heading.heading)) {
          headings.push({ ...heading, element, ...getElementPosition(element) });
        }
        return;
      }

      const matchedName = findKnownCardNameInText(text, knownNameList);
      if (matchedName) cardRows.push({ matchedName, element, ...getElementPosition(element) });
    });

    if (!headings.length || !cardRows.length) return counts;

    const countedHeadings = new Set();
    headings.forEach((heading) => {
      const nextTop = findNextHeadingTopInColumn(heading, headings);
      const hasCardInGroup = cardRows.some((row) => isRowUnderHeading(row, heading, nextTop));
      if (!hasCardInGroup) return;

      const headingKey = `${heading.heading}:${heading.count}:${Math.round(heading.left)}:${Math.round(heading.top)}`;
      if (countedHeadings.has(headingKey)) return;
      countedHeadings.add(headingKey);
      counts.set(heading.heading, Math.max(counts.get(heading.heading) || 0, heading.count));
    });

    return counts;
  }

  function findNextHeadingTopInColumn(heading, headings) {
    const nextHeading = headings
      .filter((candidate) => candidate.top > heading.top + 4 && Math.abs(candidate.left - heading.left) < 120)
      .sort((a, b) => a.top - b.top)[0];
    return nextHeading?.top || Number.POSITIVE_INFINITY;
  }

  function isRowUnderHeading(row, heading, nextTop) {
    return row.top > heading.top + 4
      && row.top < nextTop - 2
      && row.left >= heading.left - 40
      && row.left < heading.left + 520;
  }

  function isUtilityHeadingAtLine(lines, index) {
    return /\b(expand|collapse)\b/i.test(lines.slice(index, index + 3).join(" "));
  }

  function collectInlineTagCounts(text, knownNames) {
    const counts = new Map();
    const knownNameList = [...knownNames].sort((a, b) => b.length - a.length);
    const lines = text.split(/\n+/).map((line) => line.trim()).filter(Boolean);

    lines.forEach((line) => {
      if (!/^(\d+)\s+/.test(line) || !line.includes("#")) return;
      const quantity = Number(line.match(/^(\d+)\s+/)?.[1] || 0);
      if (!quantity) return;

      const cardText = line.slice(line.match(/^(\d+)\s+/)[0].length).split("#")[0].trim();
      const normalizedCardText = normalizeBulkEditCardName(cardText);
      const matchesKnownCard = knownNameList.some((name) => isKnownCardName(normalizedCardText, name));
      if (!matchesKnownCard) return;

      extractInlineTags(line).forEach((tag) => {
        counts.set(tag, (counts.get(tag) || 0) + quantity);
      });
    });

    return counts;
  }

  function isKnownCardName(cardTextName, knownName) {
    return cardTextName === knownName
      || cardTextName.startsWith(`${knownName} //`)
      || knownName.startsWith(`${cardTextName} //`);
  }

  function findKnownCardNameInText(text, knownNameList) {
    const normalizedText = normalizeBulkEditCardName(text).replace(/^\d+\s+/, "");
    return knownNameList.find((name) => {
      return isKnownCardName(normalizedText, name)
        || normalizedText.startsWith(`${name} `)
        || normalizedText.includes(` ${name} `);
    }) || "";
  }

  function extractInlineTags(line) {
    const tags = [];
    const tagPattern = /#!?([^#]+)/g;
    let match;
    while ((match = tagPattern.exec(line)) !== null) {
      const tag = match[1].trim();
      if (tag) tags.push(tag);
    }
    return tags;
  }

  function getVisibleDeckText() {
    const chunks = [];
    if (document.body?.innerText) chunks.push(document.body.innerText);

    const textareas = [...(document.querySelectorAll?.("textarea") || [])];
    textareas.forEach((textarea) => {
      if (textarea.closest?.(`#${TAGIT_ID}`)) return;
      if (textarea.value) chunks.push(textarea.value);
    });

    const editables = [...(document.querySelectorAll?.('[contenteditable="true"], [role="textbox"], .cm-content') || [])];
    editables.forEach((editable) => {
      if (editable.closest?.(`#${TAGIT_ID}`)) return;
      const text = editable.innerText || editable.textContent || "";
      if (text) chunks.push(text);
    });

    return chunks.join("\n").trim();
  }

  function parseVisibleTagHeading(line) {
    const match = line.match(/^(.+?)\s*\(\d+\)(?:\s*[-—].*)?$/);
    if (!match) return "";
    const heading = match[1].trim();
    if (!heading || /\d+\s+(main deck|sideboard)/i.test(heading)) return "";
    return heading;
  }

  function parseVisibleTagHeadingSafe(line) {
    const match = line.match(/^(.+?)\s*\(\d+\)(?:\s*(?:-|—|–|â€”).*)?$/);
    if (!match) return "";
    const heading = match[1].trim();
    if (!heading || /\d+\s+(main deck|sideboard)/i.test(heading)) return "";
    return heading;
  }

  function parseVisibleTagHeading(line) {
    return parseVisibleTagHeadingSafe(line);
  }

  function parseVisibleTagHeadingSafe(line) {
    return parseVisibleTagHeadingInfo(line)?.heading || "";
  }

  function parseVisibleTagHeadingInfo(line) {
    const visibleLine = cleanupVisibleName(line);
    if (/\b(expand|collapse)\b/i.test(visibleLine)) return null;

    const match = visibleLine.match(/^(.+?)\s*\((\d+)\)(?=$|\s|[-\u2013\u2014])/u);
    if (!match) return null;
    const heading = match[1].trim();
    if (!heading || heading.length > 60 || /\d+\s+(main deck|sideboard)/i.test(heading)) return null;
    return { heading, count: Number(match[2]) || 0 };
  }

  function parseSplitVisibleTagHeading(lines) {
    if (!lines.length) return null;

    const singleLineHeading = parseVisibleTagHeadingInfo(lines[0]);
    if (singleLineHeading) return { ...singleLineHeading, linesConsumed: 1 };

    if (lines.length < 2 || /\b(expand|collapse)\b/i.test(lines.slice(0, 3).join(" "))) return null;
    const countMatch = lines[1].match(/^\((\d+)\)$/);
    if (!countMatch) return null;

    const heading = lines[0].trim();
    if (!heading || heading.length > 60 || /\d+\s+(main deck|sideboard)/i.test(heading)) return null;
    return { heading, count: Number(countMatch[1]) || 0, linesConsumed: 2 };
  }

  function isIgnoredVisibleHeading(heading) {
    return IGNORED_VISIBLE_HEADINGS.has(heading);
  }

  function collectVisibleTagMapFromDom(deckNames) {
    const headingElements = [...document.body.querySelectorAll("h1, h2, h3, h4, h5, strong, b, div, span")]
      .map((element) => ({
        element,
        heading: parseVisibleTagHeadingSafe(element.textContent?.trim() || ""),
        top: getElementTop(element)
      }))
      .filter((item) => item.heading && !isIgnoredVisibleHeading(item.heading) && Number.isFinite(item.top))
      .sort((a, b) => a.top - b.top);

    if (!headingElements.length || !deckNames.length) return new Map();

    const tagMap = new Map();
    deckNames.forEach((name) => {
      const normalized = normalizeBulkEditCardName(name);
      const cardElements = [...document.body.querySelectorAll("a, span, div")]
        .filter((element) => normalizeBulkEditCardName(element.textContent || "") === normalized)
        .map((element) => ({ top: getElementTop(element) }))
        .filter((item) => Number.isFinite(item.top));

      cardElements.forEach(({ top }) => {
        const heading = findNearestPreviousHeading(headingElements, top);
        if (!heading) return;
        const tags = tagMap.get(normalized) || [];
        if (!tags.includes(heading.heading)) tags.push(heading.heading);
        tagMap.set(normalized, tags);
      });
    });

    return tagMap;
  }

  function findNearestPreviousHeading(headings, top) {
    let nearest = null;
    for (const heading of headings) {
      if (heading.top >= top) break;
      nearest = heading;
    }
    return nearest;
  }

  function getElementTop(element) {
    const rect = element.getBoundingClientRect();
    return rect.top + window.scrollY;
  }

  function getElementPosition(element) {
    const rect = element.getBoundingClientRect?.();
    const scrollY = typeof window === "undefined" ? 0 : window.scrollY || 0;
    const scrollX = typeof window === "undefined" ? 0 : window.scrollX || 0;
    return {
      top: (rect?.top || 0) + scrollY,
      left: (rect?.left || 0) + scrollX
    };
  }

  function getProtectedZoneNames(deck) {
    const names = [
      ...Object.values(deck.commanders || {}).map(getEntryName),
      ...Object.values(deck.sideboard || {}).map(getEntryName)
    ];
    return new Set(names.filter(Boolean).map(normalizeCardName));
  }

  function getEntryName(entry) {
    const card = entry.card || entry;
    return card.name || entry.name || "";
  }

  function collectVisibleDeck() {
    const ignored = new Set(["Primer", "Playtest", "Bulk Edit", "Buy Deck", "More", "Change"]);
    const mainboard = {};
    const commanders = {};
    const sideboard = {};
    const lines = getVisibleDeckText().split(/\n+/).map((line) => line.trim()).filter(Boolean);
    let currentZone = "mainboard";

    for (let index = 0; index < lines.length; index += 1) {
      const line = lines[index];
      if (/^Commander\s*\(/i.test(line)) {
        currentZone = "commanders";
        continue;
      }
      if (/^Sideboard\s*\(/i.test(line)) {
        currentZone = "sideboard";
        continue;
      }
      if (/^[A-Za-z][\w\s'/-]+\s*\(\d+\)$/i.test(line)) {
        currentZone = "mainboard";
        continue;
      }
      if (ignored.has(line) || /^(Add to|Buy @|Sell @|Change price|Find and add)/i.test(line)) continue;

      let match = line.match(/^(\d+)\s+(.+)$/);
      if (!match && /^\d+$/.test(line) && lines[index + 1]) {
        match = [null, line, lines[index + 1]];
        index += 1;
      }
      if (!match) continue;

      const quantity = Number(match[1]);
      const name = cleanupBulkEditCardName(match[2]);
      if (!quantity || !name || ignored.has(name) || name.length > 80) continue;

      const zone = currentZone === "commanders" ? commanders : currentZone === "sideboard" ? sideboard : mainboard;
      if (!zone[name]) {
        zone[name] = { quantity, card: { name } };
      }
    }

    removeProtectedZoneDuplicates({ commanders, sideboard }, mainboard);
    return { commanders, mainboard, sideboard, considering: {} };
  }

  function removeProtectedZoneDuplicates(protectedZones, mainboard) {
    const protectedNames = new Set([
      ...Object.keys(protectedZones.commanders || {}),
      ...Object.keys(protectedZones.sideboard || {})
    ].map(normalizeCardName));
    Object.keys(mainboard).forEach((name) => {
      if (protectedNames.has(normalizeCardName(name))) delete mainboard[name];
    });
  }

  function normalizeCardName(name) {
    return String(name).toLowerCase().replace(/\s+/g, " ").trim();
  }

  function normalizeBulkEditCardName(name) {
    return normalizeCardName(cleanupBulkEditCardName(name));
  }

  function cleanupVisibleName(name) {
    return name
      .replace(/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]+/gu, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function cleanupBulkEditCardName(name) {
    return cleanupVisibleName(name)
      .replace(/\s+#.*$/, "")
      .replace(/\s+\*[A-Z]+\*$/i, "")
      .replace(/\s+\([A-Z0-9]{2,8}\)\s+[^\s#]+(?:\s+\*[A-Z]+\*)?$/i, "")
      .replace(/\s+\([A-Z0-9]{2,8}\)$/i, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function normalizeExistingTags(entry) {
    const values = [
      ...extractTagValues(entry.tags),
      ...extractTagValues(entry.card?.tags),
      ...extractTagValues(entry.customTags),
      ...extractTagValues(entry.card?.customTags)
    ];
    return values.map(getTagName).filter(Boolean);
  }

  function extractTagValues(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    if (typeof value === "string") return [value];
    if (typeof value !== "object") return [];

    return Object.entries(value).flatMap(([key, tagValue]) => {
      if (tagValue === true || tagValue === null) return [key];
      if (typeof tagValue === "string") return [tagValue];
      if (typeof tagValue === "object") return [tagValue.name || tagValue.tag || tagValue.value || key];
      return [];
    });
  }

  function getTagName(tag) {
    const value = typeof tag === "string" ? tag : tag?.name || tag?.tag || tag?.value || "";
    return String(value).replace(/^#!/, "").replace(/^#/, "").trim();
  }

  async function enrichEntry(entry) {
    const card = entry.card || {};
    if (card.oracle_text || card.oracleText || card.type_line || card.typeLine) return entry;
    try {
      const scryfall = await sendMessage({ type: "fetchJson", url: `https://api.scryfall.com/cards/named?exact=${encodeURIComponent(entry.name)}` });
      return { ...entry, card: { ...card, ...scryfall } };
    } catch {
      return entry;
    }
  }

  function classify(entry) {
    const card = entry.card || {};
    const name = entry.name;
    const oracle = getOracleText(card);
    const typeLine = card.type_line || card.typeLine || "";
    const tags = new Set(entry.existingTags || []);

    if (isProtectedZone(entry.zone)) return [];
    removeZoneOnlyTags(tags);
    if (state.options.ignoreTagged && tags.size) return [...tags];

    const land = isLand(card);
    if (land) {
      tags.add("Land");
      if (isMdfcLand(card)) tags.add("MDFC Land");
      if (isUtilityLand(card)) tags.add("Utility Land");
    }

    for (const rule of TAG_RULES) {
      if (land && !state.options.includeLands && !rule.allowWhenLandsDisabled) continue;
      if (rule.group === "removalDetail" && !state.options.splitRemoval) continue;
      if (matchesRule(rule, { name, oracle, typeLine })) tags.add(rule.tag);
    }

    if (land && !state.options.includeLands) {
      tags.delete("Land");
      tags.delete("MDFC Land");
      tags.delete("Utility Land");
    }

    if (!state.options.splitRemoval && hasAnyDetailedRemoval(tags)) {
      removeDetailedRemovalTags(tags);
      tags.add("Removal");
    }

    cleanupConflictingTags(tags, land);
    if (!hasDrawEffect(oracle)) removeDrawEffectTags(tags);

    if (typeLine.includes("Creature") && !tags.size) tags.add("Threat");

    return [...tags].slice(0, state.options.maxTagsPerCard);
  }

  function matchesRule(rule, cardInfo) {
    const { name, oracle, typeLine } = cardInfo;
    const nameMatch = rule.names?.some((candidate) => candidate.toLowerCase() === name.toLowerCase());
    const excludedName = rule.excludeNames?.some((candidate) => candidate.toLowerCase() === name.toLowerCase());
    const textMatch = rule.tests?.some((regex) => regex.test(oracle));
    const excluded = rule.exclude?.some((regex) => regex.test(oracle));
    const hasRequiredTypes = !rule.typeIncludes || rule.typeIncludes.every((type) => typeLine.includes(type));
    const hasAnyRequiredType = !rule.typeIncludesAny || rule.typeIncludesAny.some((type) => typeLine.includes(type));
    const hasExcludedType = rule.typeExcludes?.some((type) => typeLine.includes(type));
    return (nameMatch || textMatch) && !excludedName && !excluded && hasRequiredTypes && hasAnyRequiredType && !hasExcludedType;
  }

  function cleanupConflictingTags(tags, isLandCard) {
    if (tags.has("Cost Reduction")) tags.delete("Ramp");
    if (tags.has("Ritual")) tags.delete("Mana Rock");
    if (isLandCard) {
      ["Ramp", "Land Ramp", "Tutor", "Fixing", "Mana Rock", "Mana Dork", "Ritual"].forEach((tag) => tags.delete(tag));
    }
  }

  function isProtectedZone(zone) {
    return zone === "Commander" || zone === "Sideboard";
  }

  function hasAnyDetailedRemoval(tags) {
    return [...tags].some((tag) => DETAILED_REMOVAL_TAGS.has(tag));
  }

  function removeDetailedRemovalTags(tags) {
    DETAILED_REMOVAL_TAGS.forEach((tag) => tags.delete(tag));
  }

  function removeDrawEffectTags(tags) {
    DRAW_EFFECT_TAGS.forEach((tag) => tags.delete(tag));
  }

  function removeZoneOnlyTags(tags) {
    ZONE_ONLY_TAGS.forEach((tag) => tags.delete(tag));
  }

  function hasDrawEffect(oracle) {
    const withoutDrawTriggers = oracle
      .replace(/\b(when|whenever|if) [^.\n,;]*\b(draw|draws|drew)\b[^,\n.]*,/gi, "")
      .replace(/\b(when|whenever|if) [^.\n,;]*\b(draw|draws|drew)\b[^.\n]*\./gi, "");

    return [
      /\b(draw|draws) (a|two|three|four|x|that many) cards?\b/i,
      /\bdraw cards equal\b/i,
      /\byou may draw\b/i,
      /\beach player draws\b/i,
      /\binvestigate\b/i
    ].some((regex) => regex.test(withoutDrawTriggers));
  }

  function isLand(card) {
    const typeLine = card.type_line || card.typeLine || "";
    const faces = card.card_faces || card.cardFaces || [];
    return typeLine.includes("Land") || faces.some((face) => (face.type_line || face.typeLine || "").includes("Land"));
  }

  function isMdfcLand(card) {
    const layout = card.layout || "";
    const typeLine = card.type_line || card.typeLine || "";
    const faces = card.card_faces || card.cardFaces || [];
    return (layout.includes("modal_dfc") || typeLine.includes("//")) && faces.some((face) => (face.type_line || face.typeLine || "").includes("Land"));
  }

  function isUtilityLand(card) {
    const typeLine = card.type_line || card.typeLine || "";
    const oracle = getOracleText(card);
    return typeLine.includes("Land") && !typeLine.includes("Basic") && Boolean(oracle.trim());
  }

  function getOracleText(card) {
    const direct = card.oracle_text || card.oracleText || "";
    const faces = card.card_faces || card.cardFaces || [];
    const faceText = faces.map((face) => face.oracle_text || face.oracleText || "").join("\n");
    return `${direct}\n${faceText}`.trim();
  }

  function renderSuggestions() {
    const tagged = state.suggestions.filter((item) => item.tags.length);
    state.output = state.suggestions.map(formatBulkLine).join("\n");
    output.value = state.output;
    output.classList.toggle("tagit-hidden", !state.output);
    copyButton.disabled = !state.output;
    fillButton.disabled = !state.output;
    renderDistribution(state.suggestions);

    results.innerHTML = tagged.slice(0, 18).map((item) => `
      <div class="tagit-card">
        <div class="tagit-card-name">${escapeHtml(item.quantity)} ${escapeHtml(item.name)}</div>
        <div class="tagit-tags">${escapeHtml(item.tags.join(", "))}</div>
      </div>
    `).join("");

    const more = tagged.length > 18 ? ` Showing 18 of ${tagged.length} tagged cards.` : "";
    setStatus(`Built a Bulk Edit list for ${state.suggestions.length} cards with ${tagged.length} tagged cards.${more}`);
  }

  function renderDistribution(items) {
    const source = getDistributionSource(items, state.options.tagMixSource, state.currentTagMixItems);
    const allSegments = getTagDistribution(source.items, source.key);
    const compactSegments = allSegments.slice(0, 8);
    distribution.classList.toggle("tagit-hidden", !allSegments.length);
    distribution.classList.toggle("expanded", state.options.tagMixExpanded);
    if (!allSegments.length) {
      distribution.innerHTML = "";
      return;
    }

    distribution.innerHTML = `
      <div class="tagit-distribution-topline">
        <div class="tagit-distribution-title">${source.title}</div>
        <div class="tagit-distribution-controls">
          <div class="tagit-distribution-switch" role="group" aria-label="Tag mix source">
            <button class="${state.options.tagMixSource === "current" ? "active" : ""}" data-mix-source="current" type="button">Current</button>
            <button class="${state.options.tagMixSource === "recommended" ? "active" : ""}" data-mix-source="recommended" type="button">Recommended</button>
          </div>
          <button class="tagit-distribution-expand" data-mix-expand type="button" aria-expanded="${state.options.tagMixExpanded ? "true" : "false"}">
            ${state.options.tagMixExpanded ? "Collapse" : "Expand"}
          </button>
        </div>
      </div>
      ${source.note ? `<div class="tagit-distribution-note">${source.note}</div>` : ""}
      ${state.options.tagMixExpanded ? renderExpandedDistribution(allSegments) : renderCompactDistribution(compactSegments)}
    `;
  }

  function renderCompactDistribution(segments) {
    return `
      <div class="tagit-distribution-bar">
        ${segments.map((segment) => `
          <span
            class="tagit-distribution-segment"
            style="width: ${segment.percent}%; background: ${segment.color};"
            title="${escapeHtml(segment.tag)} ${segment.percentLabel}%"
          ></span>
        `).join("")}
      </div>
      <div class="tagit-distribution-legend">
        ${segments.map((segment) => `
          <span class="tagit-distribution-item">
            <span class="tagit-distribution-dot" style="background: ${segment.color};"></span>
            <span>${escapeHtml(segment.tag)} ${segment.percentLabel}%</span>
          </span>
        `).join("")}
      </div>
    `;
  }

  function renderExpandedDistribution(segments) {
    const maxCount = Math.max(...segments.map((segment) => segment.count), 1);
    return `
      <div class="tagit-distribution-chart">
        ${segments.map((segment) => {
          const width = ((segment.count / maxCount) * 100).toFixed(3);
          return `
            <div class="tagit-chart-row">
              <div class="tagit-chart-label" title="${escapeHtml(segment.tag)}">${escapeHtml(segment.tag)}</div>
              <div class="tagit-chart-track">
                <span class="tagit-chart-fill" style="width: ${width}%; background: ${segment.color};"></span>
              </div>
              <div class="tagit-chart-value">${segment.percentLabel}%</div>
            </div>
          `;
        }).join("")}
      </div>
    `;
  }

  function getDistributionSource(items, requestedSource = "current", currentItems = []) {
    const visibleCurrentItems = currentItems.filter((item) => item.existingTags?.length);
    const existingItems = visibleCurrentItems.length ? visibleCurrentItems : items.filter((item) => item.existingTags?.length);
    const recommendedItems = items.filter((item) => item.tags.length);

    if (requestedSource === "current" && existingItems.length) {
      return {
        title: "Current Tag Mix",
        key: "existingTags",
        items: existingItems
      };
    }

    if (requestedSource === "current" && !existingItems.length) {
      return {
        title: "Recommended Tag Mix",
        note: "No current deck tags found, so this is using Tagit recommendations.",
        key: "tags",
        items: recommendedItems
      };
    }

    return {
      title: "Recommended Tag Mix",
      key: "tags",
      items: recommendedItems
    };
  }

  function getTagDistribution(items, key = "tags") {
    const counts = new Map();
    let total = 0;
    items.forEach((item) => {
      (item[key] || []).forEach((tag) => {
        counts.set(tag, (counts.get(tag) || 0) + 1);
        total += 1;
      });
    });
    if (!total) return [];

    const palette = ["#00f5ff", "#ff2bd6", "#f8ff2f", "#7c4dff", "#00ff85", "#ff7a18", "#ff3d5a", "#45a3ff"];
    return [...counts.entries()]
      .sort((a, b) => b[1] - a[1] || a[0].localeCompare(b[0]))
      .map(([tag, count], index) => {
        const rawPercent = (count / total) * 100;
        return {
          tag,
          count,
          percent: Math.max(rawPercent, 1.5).toFixed(3),
          percentLabel: rawPercent.toFixed(rawPercent >= 10 ? 1 : 1),
          color: palette[index % palette.length]
        };
      });
  }

  function formatBulkLine(item) {
    const tags = item.tags.map((tag) => `#${tag}`).join(" ");
    return `${item.quantity} ${item.name}${tags ? ` ${tags}` : ""}`;
  }

  function setBusy(isBusy, message) {
    analyzeButton.disabled = isBusy;
    if (message) setStatus(message);
  }

  function setStatus(message) {
    status.textContent = message;
  }

  function wait(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function fillBulkEditor(text) {
    const textarea = findBulkTextarea();
    if (textarea) {
      textarea.focus();
      textarea.value = text;
      textarea.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      textarea.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }

    const editable = document.querySelector('[contenteditable="true"][role="textbox"], [contenteditable="true"].cm-content');
    if (editable) {
      editable.focus();
      document.execCommand("selectAll", false, null);
      document.execCommand("insertText", false, text);
      editable.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      return true;
    }

    return false;
  }

  function findBulkTextarea() {
    const textareas = [...document.querySelectorAll("textarea")];
    return textareas.find((textarea) => {
      const label = [
        textarea.getAttribute("aria-label"),
        textarea.getAttribute("placeholder"),
        textarea.closest("form")?.textContent
      ].filter(Boolean).join(" ").toLowerCase();
      return label.includes("bulk") || label.includes("deck") || textarea.value.split("\n").length > 4;
    }) || null;
  }

  function clickBulkEdit() {
    const candidates = [...document.querySelectorAll("a, button")];
    const target = candidates.find((element) => element.textContent?.trim().toLowerCase() === "bulk edit");
    if (!target) return false;
    target.click();
    return true;
  }

  function sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        if (!response?.ok) {
          reject(new Error(response?.error || "The extension could not fetch that data."));
          return;
        }
        resolve(response.data);
      });
    });
  }

  function escapeHtml(value) {
    return String(value).replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#039;"
    })[char]);
  }
})();
