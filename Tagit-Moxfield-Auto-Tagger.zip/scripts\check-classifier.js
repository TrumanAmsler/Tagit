const fs = require("fs");
const vm = require("vm");

const source = fs.readFileSync("src/content.js", "utf8");
const sandbox = {
  document: { getElementById: () => true },
  console
};

vm.runInNewContext(source, sandbox);

const classify = sandbox.__tagitTest.classifyForTest;
const collectDeckEntries = sandbox.__tagitTest.collectDeckEntriesForTest;
const getTagDistribution = sandbox.__tagitTest.getTagDistributionForTest;
const getDistributionSource = sandbox.__tagitTest.getDistributionSourceForTest;
const collectVisibleTagMixItems = sandbox.__tagitTest.collectVisibleTagMixItemsForTest;
const collectVisibleTagCounts = sandbox.__tagitTest.collectVisibleTagCountsForTest;
const formatBulkLine = sandbox.__tagitTest.formatBulkLineForTest;

const cases = [
  {
    name: "Chasm Skulker",
    card: {
      name: "Chasm Skulker",
      type_line: "Creature - Squid Horror",
      oracle_text: "Whenever you draw a card, put a +1/+1 counter on Chasm Skulker.\nWhen Chasm Skulker dies, create X 1/1 blue Squid creature tokens with islandwalk, where X is the number of +1/+1 counters on Chasm Skulker."
    },
    mustNotInclude: ["Draw", "Card Advantage", "Cantrip"],
    mustInclude: ["Payoff", "Tokens"]
  },
  {
    name: "Loran of the Third Path",
    card: {
      name: "Loran of the Third Path",
      type_line: "Legendary Creature - Human Artificer",
      oracle_text: "Vigilance\nWhen Loran of the Third Path enters the battlefield, destroy up to one target artifact or enchantment.\n{T}: You and target opponent each draw a card."
    },
    mustInclude: ["Draw"]
  },
  {
    name: "Counterspell",
    card: {
      name: "Counterspell",
      type_line: "Instant",
      oracle_text: "Counter target spell."
    },
    mustInclude: ["Counterspell"]
  },
  {
    name: "Shorikai, Genesis Engine",
    zone: "Commander",
    existingTags: ["Commander"],
    card: {
      name: "Shorikai, Genesis Engine",
      type_line: "Legendary Artifact - Vehicle",
      oracle_text: "{1}, {T}: Draw two cards, then discard a card. Create a 1/1 colorless Pilot creature token with 'This creature crews Vehicles as though its power were 2 greater.'"
    },
    mustNotInclude: ["Commander", "Draw", "Tokens"]
  },
  {
    name: "Aether Gale",
    zone: "Sideboard",
    card: {
      name: "Aether Gale",
      type_line: "Sorcery",
      oracle_text: "Return six target nonland permanents to their owners' hands."
    },
    mustNotInclude: ["Bounce", "Removal"]
  },
  {
    name: "Fog",
    card: {
      name: "Fog",
      type_line: "Instant",
      oracle_text: "Prevent all combat damage that would be dealt this turn."
    },
    mustInclude: ["Fog"]
  },
  {
    name: "Claim the Firstborn",
    card: {
      name: "Claim the Firstborn",
      type_line: "Sorcery",
      oracle_text: "Gain control of target creature with mana value 3 or less until end of turn. Untap that creature. It gains haste until end of turn."
    },
    mustInclude: ["Theft"]
  },
  {
    name: "Evolution Sage",
    card: {
      name: "Evolution Sage",
      type_line: "Creature - Elf Druid",
      oracle_text: "Landfall - Whenever a land enters the battlefield under your control, proliferate."
    },
    mustInclude: ["Proliferate"]
  },
  {
    name: "Wasteland",
    card: {
      name: "Wasteland",
      type_line: "Land",
      oracle_text: "{T}: Add {C}.\n{T}, Sacrifice Wasteland: Destroy target nonbasic land."
    },
    mustInclude: ["Land Hate"],
    mustNotInclude: ["Land", "Utility Land"]
  },
  {
    name: "Oko, Thief of Crowns",
    card: {
      name: "Oko, Thief of Crowns",
      type_line: "Legendary Planeswalker - Oko",
      oracle_text: "+1: Target artifact or creature loses all abilities and becomes a green Elk creature with base power and toughness 3/3."
    },
    mustInclude: ["Control"]
  },
  {
    name: "Imprisoned in the Moon",
    card: {
      name: "Imprisoned in the Moon",
      type_line: "Enchantment - Aura",
      oracle_text: "Enchant creature, land, or planeswalker\nEnchanted permanent is a colorless land with \"{T}: Add {C}\" and loses all other card types and abilities."
    },
    mustInclude: ["Control"]
  },
  {
    name: "Tezzeret, Cruel Captain",
    card: {
      name: "Tezzeret, Cruel Captain",
      type_line: "Legendary Planeswalker - Tezzeret",
      oracle_text: "+1: Untap up to one target artifact or creature.\n-3: Search your library for an artifact card with mana value 1 or less, reveal it, put it into your hand, then shuffle."
    },
    mustInclude: ["Tutor"],
    mustNotInclude: ["Control"]
  },
  {
    name: "Command Tower",
    card: {
      name: "Command Tower",
      type_line: "Land",
      oracle_text: "{T}: Add one mana of any color in your commander's color identity."
    },
    mustNotInclude: ["Ramp", "Fixing", "Tutor"]
  },
  {
    name: "Prismatic Vista",
    card: {
      name: "Prismatic Vista",
      type_line: "Land",
      oracle_text: "{T}, Pay 1 life, Sacrifice Prismatic Vista: Search your library for a basic land card, put it onto the battlefield, then shuffle."
    },
    mustNotInclude: ["Ramp", "Land Ramp", "Tutor"]
  },
  {
    name: "Expedition Map",
    card: {
      name: "Expedition Map",
      type_line: "Artifact",
      oracle_text: "{2}, {T}, Sacrifice Expedition Map: Search your library for a land card, reveal it, put it into your hand, then shuffle."
    },
    mustNotInclude: ["Ramp", "Land Ramp", "Tutor"]
  },
  {
    name: "It That Heralds the End",
    card: {
      name: "It That Heralds the End",
      type_line: "Creature - Eldrazi Drone",
      oracle_text: "Colorless spells you cast with mana value 7 or greater cost {1} less to cast."
    },
    mustInclude: ["Cost Reduction"],
    mustNotInclude: ["Ramp"]
  },
  {
    name: "An Offer You Can't Refuse",
    card: {
      name: "An Offer You Can't Refuse",
      type_line: "Instant",
      oracle_text: "Counter target noncreature spell. Its controller creates two Treasure tokens. (They're artifacts with \"{T}, Sacrifice this artifact: Add one mana of any color.\")"
    },
    mustInclude: ["Counterspell"],
    mustNotInclude: ["Ramp", "Ritual", "Fixing"]
  },
  {
    name: "Runadi, Behemoth Caller",
    card: {
      name: "Runadi, Behemoth Caller",
      type_line: "Legendary Creature - Cat Shaman",
      oracle_text: "Whenever you cast a creature spell with mana value 5 or greater, that creature enters the battlefield with X additional +1/+1 counters on it, where X is its mana value minus 4.\nCreatures you control with three or more +1/+1 counters on them have haste.\n{T}: Add {G}."
    },
    mustInclude: ["Mana Dork", "+X/+-X", "Haste"]
  },
  {
    name: "Ulamog, the Ceaseless Hunger",
    card: {
      name: "Ulamog, the Ceaseless Hunger",
      type_line: "Legendary Creature - Eldrazi",
      oracle_text: "When you cast this spell, exile two target permanents.\nIndestructible\nWhenever Ulamog attacks, defending player exiles the top twenty cards of their library."
    },
    mustInclude: ["Removal", "Wincon"]
  },
  {
    name: "Ugin's Binding",
    card: {
      name: "Ugin's Binding",
      type_line: "Enchantment",
      oracle_text: "When Ugin's Binding enters the battlefield, return target nonland permanent an opponent controls to its owner's hand.\nWhenever you cast a colorless spell with mana value 7 or greater, you may exile Ugin's Binding from your graveyard. When you do, return each nonland permanent you don't control to its owner's hand."
    },
    mustInclude: ["Board Wipe"],
    mustNotInclude: ["Graveyard Hate"]
  },
  {
    name: "All Is Dust",
    card: {
      name: "All Is Dust",
      type_line: "Kindred Sorcery - Eldrazi",
      oracle_text: "Each player sacrifices all colored permanents they control."
    },
    mustInclude: ["Board Wipe"]
  },
  {
    name: "Kozilek's Unsealing",
    card: {
      name: "Kozilek's Unsealing",
      type_line: "Enchantment",
      oracle_text: "Whenever you cast a creature spell with mana value 4, 5, or 6, create two 0/1 colorless Eldrazi Spawn creature tokens.\nWhenever you cast a creature spell with mana value 7 or greater, draw three cards."
    },
    mustInclude: ["Card Advantage", "Payoff"]
  },
  {
    name: "Chain of Vapor",
    card: {
      name: "Chain of Vapor",
      type_line: "Instant",
      oracle_text: "Return target nonland permanent to its owner's hand. Then that permanent's controller may sacrifice a land. If the player does, they may copy this spell and may choose a new target for that copy."
    },
    mustInclude: ["Removal"],
    mustNotInclude: ["Copy"]
  },
  {
    name: "The Aetherspark",
    card: {
      name: "The Aetherspark",
      type_line: "Legendary Artifact - Equipment",
      oracle_text: "{T}: Add three mana in any combination of colors. This mana doesn't empty from your mana pool as steps and phases end."
    },
    mustInclude: ["Ritual"],
    mustNotInclude: ["Mana Rock"]
  },
  {
    name: "Thoughtseize",
    card: {
      name: "Thoughtseize",
      type_line: "Sorcery",
      oracle_text: "Target player reveals their hand. You choose a nonland card from it. That player discards that card. You lose 2 life."
    },
    mustInclude: ["Control"]
  },
  {
    name: "Shifting Grift",
    card: {
      name: "Shifting Grift",
      type_line: "Sorcery",
      oracle_text: "Exchange control of two target permanents that share a card type."
    },
    mustInclude: ["Control"],
    mustNotInclude: ["Theft"]
  }
];

for (const test of cases) {
  const tags = classify({ zone: test.zone || "Mainboard", quantity: 1, name: test.name, card: test.card, existingTags: test.existingTags || [] });
  for (const tag of test.mustInclude || []) {
    if (!tags.includes(tag)) throw new Error(`${test.name} should include ${tag}. Got: ${tags.join(", ")}`);
  }
  for (const tag of test.mustNotInclude || []) {
    if (tags.includes(tag)) throw new Error(`${test.name} should not include ${tag}. Got: ${tags.join(", ")}`);
  }
}

const protectedZoneEntries = collectDeckEntries({
  commanders: {
    commander: {
      quantity: 1,
      card: { name: "Shorikai, Genesis Engine" }
    }
  },
  sideboard: {
    sideboardCard: {
      quantity: 1,
      card: { name: "Aether Gale" }
    }
  },
  mainboard: {
    duplicate: {
      quantity: 1,
      card: { name: "Shorikai, Genesis Engine" }
    },
    sideboardDuplicate: {
      quantity: 1,
      card: { name: "Aether Gale" }
    },
    solRing: {
      quantity: 1,
      card: { name: "Sol Ring" }
    }
  }
});

const commanderCopies = protectedZoneEntries.filter((entry) => entry.name === "Shorikai, Genesis Engine");
if (commanderCopies.length !== 0) {
  throw new Error(`Commander should not be emitted for tagging. Got: ${JSON.stringify(commanderCopies)}`);
}

const sideboardCopies = protectedZoneEntries.filter((entry) => entry.name === "Aether Gale");
if (sideboardCopies.length !== 0) {
  throw new Error(`Sideboard cards should not be emitted for tagging. Got: ${JSON.stringify(sideboardCopies)}`);
}

const solRingCopies = protectedZoneEntries.filter((entry) => entry.name === "Sol Ring");
if (solRingCopies.length !== 1 || solRingCopies[0].zone !== "Mainboard") {
  throw new Error(`Mainboard cards should still be emitted once. Got: ${JSON.stringify(solRingCopies)}`);
}

const existingTagEntries = collectDeckEntries({
  commanders: {},
  sideboard: {},
  mainboard: {
    skullclamp: {
      quantity: 1,
      tags: { Draw: true, Payoff: { name: "Payoff" } },
      card: { name: "Skullclamp" }
    }
  }
});

if (existingTagEntries[0]?.existingTags.join(",") !== "Draw,Payoff") {
  throw new Error(`Object-shaped existing tags should be normalized. Got: ${JSON.stringify(existingTagEntries)}`);
}

const distribution = getTagDistribution([
  { tags: ["Ramp", "Mana Rock"] },
  { tags: ["Ramp"] },
  { tags: ["Draw"] }
]);

if (distribution[0]?.tag !== "Ramp" || distribution[0]?.percentLabel !== "50.0") {
  throw new Error(`Tag distribution should rank Ramp at 50.0%. Got: ${JSON.stringify(distribution)}`);
}

const manyTagDistribution = getTagDistribution([
  { tags: ["A", "B", "C", "D", "E", "F", "G", "H", "I"] }
]);

if (manyTagDistribution.length !== 9) {
  throw new Error(`Expanded distribution needs all tags, not top 8 only. Got: ${JSON.stringify(manyTagDistribution)}`);
}

const existingDistributionSource = getDistributionSource([
  { existingTags: ["Current"], tags: ["Recommended"] },
  { existingTags: ["Current"], tags: ["Recommended"] },
  { existingTags: [], tags: ["Recommended"] }
]);

if (existingDistributionSource.title !== "Current Tag Mix" || existingDistributionSource.key !== "existingTags") {
  throw new Error(`Distribution should prefer existing tags. Got: ${JSON.stringify(existingDistributionSource)}`);
}

const existingDistribution = getTagDistribution(existingDistributionSource.items, existingDistributionSource.key);
if (existingDistribution[0]?.tag !== "Current" || existingDistribution[0]?.percentLabel !== "100.0") {
  throw new Error(`Existing tag distribution should use current tags only. Got: ${JSON.stringify(existingDistribution)}`);
}

const fallbackDistributionSource = getDistributionSource([
  { existingTags: [], tags: ["Recommended"] }
]);

if (fallbackDistributionSource.title !== "Recommended Tag Mix" || fallbackDistributionSource.key !== "tags") {
  throw new Error(`Distribution should fall back to recommended tags. Got: ${JSON.stringify(fallbackDistributionSource)}`);
}

const recommendedDistributionSource = getDistributionSource([
  { existingTags: ["Current"], tags: ["Recommended"] }
], "recommended");

if (recommendedDistributionSource.title !== "Recommended Tag Mix" || recommendedDistributionSource.key !== "tags") {
  throw new Error(`Distribution should use recommended tags when requested. Got: ${JSON.stringify(recommendedDistributionSource)}`);
}

const visibleCurrentSource = getDistributionSource(
  [{ existingTags: [], tags: ["Recommended"] }],
  "current",
  [{ existingTags: ["Draw", "Draw", "Tutor"], tags: ["Draw", "Draw", "Tutor"] }]
);

if (visibleCurrentSource.title !== "Current Tag Mix" || visibleCurrentSource.items[0].existingTags.length !== 3) {
  throw new Error(`Visible current tag mix should drive Current mode separately. Got: ${JSON.stringify(visibleCurrentSource)}`);
}

sandbox.document.body = {
  innerText: [
    "Main Deck (99)",
    "1 Ambition's Cost (MOC) 246 #Draw",
    "1 Arachnogenesis (DSC) 169 #Fodder #Fog",
    "1 Ancient Tomb (EOS) 46"
  ].join("\n")
};

const inlineTagCounts = collectVisibleTagCounts(["Ambition's Cost", "Arachnogenesis", "Ancient Tomb"]);
if (inlineTagCounts.get("Draw") !== 1 || inlineTagCounts.get("Fodder") !== 1 || inlineTagCounts.get("Fog") !== 1) {
  throw new Error(`Inline bulk-edit tags should be counted from visible text. Got: ${JSON.stringify([...inlineTagCounts])}`);
}

sandbox.document.body = { innerText: "" };
sandbox.document.querySelectorAll = (selector) => {
  if (selector !== "textarea") return [];
  return [{
    value: [
      "Main Deck (99)",
      "1 Ambition's Cost (MOC) 246 #Draw",
      "1 Arachnogenesis (DSC) 169 #Fodder #Fog",
      "1 Ancient Tomb (EOS) 46"
    ].join("\n"),
    closest: () => null
  }];
};

const textareaTagCounts = collectVisibleTagCounts([
  "Ambition's Cost (MOC) 246 #Draw",
  "Arachnogenesis (DSC) 169 #Fodder #Fog",
  "Ancient Tomb (EOS) 46"
]);
if (textareaTagCounts.get("Draw") !== 1 || textareaTagCounts.get("Fodder") !== 1 || textareaTagCounts.get("Fog") !== 1) {
  throw new Error(`Bulk Edit textarea tags should be counted from dirty visible names. Got: ${JSON.stringify([...textareaTagCounts])}`);
}

sandbox.document.body = {
  innerText: [
    "Main Deck (99)",
    "Commander (2) - $4.51 Change",
    "1 Abby, Merciless Soldier",
    "1 Ellie, Vengeful Hunter",
    "Steal (6) \u2014 $2.10",
    "1 Claim the Firstborn",
    "1 Traitorous Greed",
    "Draw (8) \u2013 $18.69",
    "1 Skullclamp",
    "1 Fecundity",
    "Tokens (12)",
    "Tokens (12) \u2013 Expand",
    "Considering (57) \u2013 Expand",
    "Recent History \u2013 Collapse"
  ].join("\n")
};
delete sandbox.document.querySelectorAll;

const mainPageTagCounts = collectVisibleTagCounts([
  "Abby, Merciless Soldier",
  "Ellie, Vengeful Hunter",
  "Claim the Firstborn",
  "Traitorous Greed",
  "Skullclamp",
  "Fecundity",
  "Predatory Impetus"
]);
if (mainPageTagCounts.get("Steal") !== 6 || mainPageTagCounts.get("Draw") !== 8 || mainPageTagCounts.has("Commander") || mainPageTagCounts.has("Main Deck") || mainPageTagCounts.has("Tokens")) {
  throw new Error(`Main page grouped tag headings should drive current tag mix. Got: ${JSON.stringify([...mainPageTagCounts])}`);
}

sandbox.document.body = {
  innerText: [
    "Tokens (3)",
    "1 Fecundity",
    "Tokens (12)",
    "Expand"
  ].join("\n")
};
delete sandbox.document.querySelectorAll;

const realTokensTagCounts = collectVisibleTagCounts(["Fecundity"]);
if (realTokensTagCounts.get("Tokens") !== 3) {
  throw new Error(`A real Tokens tag group with a main-deck card should still count. Got: ${JSON.stringify([...realTokensTagCounts])}`);
}

sandbox.document.body = { innerText: "Deck page with rendered tag headings." };
const makeElement = (text, top, left, inTagit = false) => ({
  innerText: text,
  textContent: text,
  closest: () => inTagit,
  getBoundingClientRect: () => ({ top, left })
});
sandbox.document.querySelectorAll = (selector) => {
  if (selector === "ul, ol, [role='list']") {
    return [
      makeElement(["Draw", "(8)", "1", "Skullclamp", "1", "Fecundity"].join("\n"), 100, 300),
      makeElement(["Steal", "(6)", "1", "Claim the Firstborn", "1", "Traitorous Greed"].join("\n"), 100, 730),
      makeElement(["Tokens", "(12)", "Expand"].join("\n"), 900, 300),
      makeElement(["Commander", "(2)", "1", "Abby, Merciless Soldier"].join("\n"), 70, 300)
    ];
  }
  return [
  makeElement("Draw (8) \u2013 $18.69", 100, 300),
  makeElement("Skullclamp", 132, 320),
  makeElement("Steal (6) \u2013", 100, 730),
  makeElement("Claim the Firstborn", 132, 750),
  makeElement("Tokens (12)", 900, 300),
  makeElement("Tokens (12) \u2013 Expand", 930, 300),
  makeElement("Commander (2) - $4.51 Change", 70, 300),
  makeElement("Tagit Recommended Tag Mix", 100, 900, true)
  ];
};

const domHeadingCounts = collectVisibleTagCounts(["Skullclamp", "Claim the Firstborn"]);
if (domHeadingCounts.get("Draw") !== 8 || domHeadingCounts.get("Steal") !== 6 || domHeadingCounts.has("Tokens") || domHeadingCounts.has("Commander")) {
  throw new Error(`DOM headings should drive main-page current tag mix while ignoring utility headings. Got: ${JSON.stringify([...domHeadingCounts])}`);
}

const bulkLine = formatBulkLine({ quantity: 1, name: "Sol Ring", tags: ["Ramp", "Mana Rock"] });
if (bulkLine !== "1 Sol Ring #Ramp #Mana Rock") {
  throw new Error(`Bulk line should use local deck tags. Got: ${bulkLine}`);
}

console.log("classifier checks ok");
